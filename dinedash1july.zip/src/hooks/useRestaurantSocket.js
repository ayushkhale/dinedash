import { useEffect } from 'react'
import { io } from 'socket.io-client'
import api from '../api'

export function useRestaurantSocket({
  user,
  setOrders,
  setWaiterCalls,
  setTables
}) {
  useEffect(() => {
    const ts = () => new Date().toISOString()

    if (!user?.restaurant_id) {
      console.warn(`[Socket][${ts()}] ⛔ Skipping — no restaurant_id on user`, user)
      return
    }

    const BASE_URL = api.baseUrl
    console.info(`[Socket][${ts()}] 🔌 Initialising connection to: ${BASE_URL}`)
    console.info(`[Socket][${ts()}] 👤 userId: ${user.id} | restaurant_id: ${user.restaurant_id}`)

    const socketConn = io(BASE_URL, {
      transports: ['polling', 'websocket'],
      query: { userId: user.id },
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    })

    socketConn.on('connect', () => {
      const roomName = `restaurant_${user.restaurant_id}`
      console.log(`[Socket][${ts()}] ✅ Connected | socket.id: ${socketConn.id} | transport: ${socketConn.io.engine.transport.name}`)

      socketConn.emit('join_room', roomName, (ack) => {
        if (ack) {
          console.log(`[Socket][${ts()}] 🏠 Room join ACK received:`, ack)
        } else {
          console.log(`[Socket][${ts()}] 🏠 Room join emitted (no ack from server): ${roomName}`)
        }
      })
    })

    socketConn.on('disconnect', (reason) => {
      console.warn(`[Socket][${ts()}] ❌ Disconnected | reason: "${reason}"`)
      if (reason === 'io server disconnect') {
        console.info(`[Socket][${ts()}] 🔄 Server-initiated disconnect — attempting manual reconnect`)
        socketConn.connect()
      }
    })

    socketConn.on('connect_error', (err) => {
      console.error(`[Socket][${ts()}] 💥 connect_error: ${err.message}`)
    })

    socketConn.on('reconnect_attempt', (attempt) => {
      console.info(`[Socket][${ts()}] 🔁 Reconnect attempt #${attempt}`)
    })

    socketConn.on('reconnect', (attempt) => {
      console.log(`[Socket][${ts()}] ♻️  Reconnected after ${attempt} attempt(s) | socket.id: ${socketConn.id}`)
    })

    socketConn.on('new_order', (newOrder) => {
      console.log(`[Socket][${ts()}] 📦 new_order received:`, newOrder)
      setOrders((prev) => [newOrder, ...prev])
    })

    socketConn.on('waiter_call', (newCall) => {
      console.log(`[Socket][${ts()}] 🛎️  waiter_call received:`, newCall)
      setWaiterCalls((prev) => [newCall, ...prev])
    })

    socketConn.on('order_status_update', (payload) => {
      console.log(`[Socket][${ts()}] 🔄 order_status_update:`, payload)
      setOrders((prev) =>
        prev.map(ord => ord.id === payload.id ? { ...ord, status: payload.status } : ord)
      )
    })

    socketConn.on('payment_status_update', (payload) => {
      console.log(`[Socket][${ts()}] 💳 payment_status_update:`, payload)
      setOrders((prev) =>
        prev.map(ord => ord.id === payload.id ? { ...ord, payment_status: payload.payment_status } : ord)
      )
    })

    socketConn.on('waiter_call_resolved', (payload) => {
      console.log(`[Socket][${ts()}] ✔️  waiter_call_resolved:`, payload)
      setWaiterCalls((prev) => prev.filter(c => c.id !== payload.id))
    })

    socketConn.on('table_session_cleared', (payload) => {
      console.log(`[Socket][${ts()}] 🧹 table_session_cleared:`, payload)
      // 1. Update matching orders status/payment
      setOrders((prev) =>
        prev.map(ord => (ord.table_id === payload.table_id || ord.RestaurantTable?.id === payload.table_id)
          ? { ...ord, payment_status: 'PAID', status: 'SERVED' }
          : ord
        )
      )
      // 2. Update table session status in tables list
      if (setTables) {
        setTables((prevTables) =>
          prevTables.map((table) =>
            table.id === payload.table_id ? { ...table, session_status: payload.session_status } : table
          )
        )
      }
    })

    return () => {
      console.info(`[Socket][${ts()}] 🧹 Cleaning up — disconnecting socket ${socketConn.id}`)
      socketConn.disconnect()
    }
  }, [user?.restaurant_id, user?.id, setOrders, setWaiterCalls, setTables])
}
