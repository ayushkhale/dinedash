import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import logoRed from '../assets/logored.png'
import api from '../api'

export default function LandingPage() {
  const navigate = useNavigate()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: 'General Inquiry', message: '' })
  const [contactSubmitted, setContactSubmitted] = useState(false)
  const [trialEmail, setTrialEmail] = useState('')
  const [trialSubmitted, setTrialSubmitted] = useState(false)
  const [printKey, setPrintKey] = useState(0)
  const [apiPlans, setApiPlans] = useState([])

  useEffect(() => {
    const fetchApiPlans = async () => {
      try {
        const res = await api.get('/api/subscriptions/plans')
        const data = res?.data ?? res
        if (Array.isArray(data) && data.length > 0) {
          setApiPlans(data)
        }
      } catch (err) {
        console.error('Failed to fetch subscription plans for landing page:', err)
      }
    }
    fetchApiPlans()
  }, [])

  const handleContactSubmit = (e) => {
    e.preventDefault()

    const mailtoLink = `mailto:compuniclimited@gmail.com?subject=${encodeURIComponent(contactForm.subject)}&body=${encodeURIComponent(
      `Name: ${contactForm.name}\nEmail: ${contactForm.email}\n\nMessage:\n${contactForm.message}`
    )}`

    window.location.href = mailtoLink

    setContactSubmitted(true)
    setTimeout(() => {
      setContactSubmitted(false)
      setContactForm({ name: '', email: '', subject: 'General Inquiry', message: '' })
    }, 3000)
  }

  const handleTrialSubmit = (e) => {
    e.preventDefault()
    if (trialEmail) {
      setTrialSubmitted(true)
      setTimeout(() => {
        setTrialSubmitted(false)
        setTrialEmail('')
        navigate('/register')
      }, 1500)
    }
  }

  // ── Billing machine sound: ting → beep beep → printer roll → done (Web Audio API) ──
  const playPrinterSound = () => {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)()
      const t = ctx.currentTime

      /* ── Helper: schedule a short sine-wave beep ───────────────────── */
      const beep = (freq, start, dur, vol = 0.45) => {
        const osc = ctx.createOscillator()
        const env = ctx.createGain()
        osc.type = 'sine'
        osc.frequency.value = freq
        env.gain.setValueAtTime(0, start)
        env.gain.linearRampToValueAtTime(vol, start + 0.01)
        env.gain.setValueAtTime(vol, start + dur - 0.03)
        env.gain.linearRampToValueAtTime(0, start + dur)
        osc.connect(env)
        env.connect(ctx.destination)
        osc.start(start)
        osc.stop(start + dur)
      }

      /* ── Helper: metallic "ting" bell hit ──────────────────────────── */
      const ting = (start) => {
        const osc1 = ctx.createOscillator()
        const osc2 = ctx.createOscillator()
        const env = ctx.createGain()
        osc1.type = 'sine'; osc1.frequency.value = 1320   // E6 bell fundamental
        osc2.type = 'sine'; osc2.frequency.value = 2640   // octave overtone
        env.gain.setValueAtTime(0, start)
        env.gain.linearRampToValueAtTime(0.55, start + 0.006)
        env.gain.exponentialRampToValueAtTime(0.0001, start + 0.9) // natural ring-out
        osc1.connect(env); osc2.connect(env); env.connect(ctx.destination)
        osc1.start(start); osc1.stop(start + 0.95)
        osc2.start(start); osc2.stop(start + 0.95)
      }

      /* ── Helper: thermal printer rolling noise ─────────────────────── */
      const printerRoll = (start, duration) => {
        const sampleRate = ctx.sampleRate
        const frames = Math.ceil(sampleRate * duration)

        // White noise buffer
        const buf = ctx.createBuffer(1, frames, sampleRate)
        const data = buf.getChannelData(0)
        for (let i = 0; i < frames; i++) data[i] = Math.random() * 2 - 1
        const noise = ctx.createBufferSource()
        noise.buffer = buf

        // Band-pass: sweeps down as printer slows
        const bpf = ctx.createBiquadFilter()
        bpf.type = 'bandpass'
        bpf.frequency.setValueAtTime(2200, start)
        bpf.frequency.exponentialRampToValueAtTime(700, start + duration)
        bpf.Q.value = 1.4

        // Sawtooth motor whine with rapid stepping wobble
        const motorOsc = ctx.createOscillator()
        motorOsc.type = 'sawtooth'
        for (let s = 0; s < duration; s += 0.035) {
          motorOsc.frequency.setValueAtTime(195 + Math.sin(s * 65) * 22, start + s)
        }

        // Envelope: ramp in, steady, ramp out
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0, start)
        gain.gain.linearRampToValueAtTime(0.3, start + 0.07)
        gain.gain.setValueAtTime(0.3, start + duration - 0.15)
        gain.gain.linearRampToValueAtTime(0, start + duration)

        const motorGain = ctx.createGain()
        motorGain.gain.setValueAtTime(0, start)
        motorGain.gain.linearRampToValueAtTime(0.1, start + 0.07)
        motorGain.gain.setValueAtTime(0.1, start + duration - 0.15)
        motorGain.gain.linearRampToValueAtTime(0, start + duration)

        noise.connect(bpf); bpf.connect(gain)
        motorOsc.connect(motorGain); motorGain.connect(gain)
        gain.connect(ctx.destination)

        noise.start(start); noise.stop(start + duration)
        motorOsc.start(start); motorOsc.stop(start + duration)
      }

      /* ── SEQUENCE (~3 s total) ──────────────────────────────────────
         0.00 — TING  (bell, rings ~0.5 s)
         0.28 — BEEP 1
         0.48 — BEEP 2
         0.68 — PRINTER ROLLS (1.9 s)
         2.72 — END BEEP
      ────────────────────────────────────────────────────────────── */
      ting(t + 0.00)
      beep(880, t + 0.28, 0.14, 0.40)   // A5 beep 1
      beep(880, t + 0.48, 0.14, 0.40)   // A5 beep 2
      printerRoll(t + 0.68, 1.90)
      beep(1175, t + 2.72, 0.18, 0.35)   // D6 done-tone

      setTimeout(() => ctx.close(), 3400)
    } catch (_) {
      // Silently fail on browsers without AudioContext
    }
  }

  const getPlanFeatures = (planId) => {
    if (planId === 'MONTHLY') {
      return [
        'Full dashboard access',
        'POS & billing integration',
        'Menu & inventory tools',
        'Kitchen display & waiter alerts'
      ]
    } else if (planId === 'YEARLY') {
      return [
        'Everything in Monthly',
        '2 months completely free',
        'Priority partner support',
        'Early access to updates'
      ]
    }
    return [
      'Full dashboard access',
      'Live KDS display',
      'UPI payments setup',
      'Priority customer support'
    ]
  }

  return (
    <div
      className="min-h-screen flex flex-col font-sans select-none antialiased"
      style={{
        backgroundColor: '#f5f3f4',
        color: '#161a1d'
      }}
    >
      {/* 1. HEADER / NAVIGATION */}
      <header className="sticky top-0 z-50 bg-[#f5f3f4]/90 backdrop-blur-md border-b border-[#d3d3d3]/80 px-6 lg:px-16 py-4 flex flex-col">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-3">
            <img
              src={logoRed}
              alt="DineDash Logo"
              className="h-10 w-auto object-contain cursor-pointer"
              onClick={() => navigate('/')}
            />
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors">Features</a>
            <a href="#pricing" className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors">Pricing</a>
            <a href="#contact" className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors">Contact</a>
            <button
              onClick={() => navigate('/login')}
              className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors cursor-pointer"
            >
              Sign in
            </button>
            <button
              onClick={() => navigate('/register')}
              className="bg-[#ba181b] hover:bg-[#a4161a] active:bg-[#660708] text-white text-xs lg:text-sm font-bold px-4 py-2 rounded-lg transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.08)] cursor-pointer"
            >
              Start free trial
            </button>
          </nav>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden flex items-center justify-center p-2 rounded-lg text-[#161a1d] hover:bg-[#d3d3d3]/40 focus:outline-none transition-colors"
          >
            {mobileMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Dropdown Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden flex flex-col gap-4 pt-4 pb-2 border-t border-[#d3d3d3]/40 mt-3 animate-fadeIn">
            <a
              href="#features"
              onClick={() => setMobileMenuOpen(false)}
              className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors py-1.5"
            >
              Features
            </a>
            <a
              href="#pricing"
              onClick={() => setMobileMenuOpen(false)}
              className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors py-1.5"
            >
              Pricing
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors py-1.5"
            >
              Contact
            </a>
            <button
              onClick={() => { setMobileMenuOpen(false); navigate('/login') }}
              className="text-left text-sm font-bold text-[#b1a7a6] hover:text-[#161a1d] transition-colors py-1.5 cursor-pointer"
            >
              Sign in
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); navigate('/register') }}
              className="bg-[#ba181b] hover:bg-[#a4161a] text-white text-xs font-bold py-2.5 rounded-lg transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.08)] cursor-pointer w-full text-center"
            >
              Start free trial
            </button>
          </div>
        )}
      </header>

      {/* 2. HERO SECTION */}
      <section className="px-6 lg:px-16 py-12 lg:py-24 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 flex flex-col items-start text-left">
          {/* Capsule Tag */}
          <span className="inline-flex items-center gap-2 bg-[#d3d3d3]/40 border border-[#b1a7a6] px-3.5 py-1.5 rounded-full text-[10px] font-bold tracking-wider uppercase text-[#161a1d] mb-6">
            Next-Gen QR Dine-in Ecosystem
          </span>

          {/* Main Headline */}
          <h1 className="font-outfit text-4xl lg:text-6xl font-black text-[#0b090a] leading-[1.1] tracking-tight mb-6">
            Scan. Order.<br />
            Serve Faster.<br />
            <span className="text-[#ba181b]">Every Single Table.</span>
          </h1>

          {/* Subtext */}
          <p className="text-[#161a1d]/85 text-base lg:text-lg leading-relaxed max-w-xl mb-8 font-semibold">
            Empower your restaurant with DineDash. Guests scan the table QR to browse visual menus, customize orders, and checkout instantly.
          </p>

          {/* CTA Form / Buttons */}
          <div className="w-full max-w-md">
            {trialSubmitted ? (
              <div className="bg-red-50 border border-red-200 text-[#ba181b] px-4 py-3 rounded-lg text-sm font-bold mb-3">
                Creating your DineDash trial workspace...
              </div>
            ) : (
              <form onSubmit={handleTrialSubmit} className="flex flex-col sm:flex-row gap-2.5 mb-3 w-full">
                <input
                  type="email"
                  value={trialEmail}
                  onChange={(e) => setTrialEmail(e.target.value)}
                  placeholder="Enter your restaurant email"
                  required
                  className="w-full sm:flex-1 px-4 py-3 rounded-lg border border-[#d3d3d3] bg-white text-[#161a1d] placeholder-[#b1a7a6] text-sm focus:outline-none focus:border-[#ba181b] focus:ring-1 focus:ring-[#ba181b] transition-all"
                />
                <button
                  type="submit"
                  className="bg-[#ba181b] hover:bg-[#a4161a] active:bg-[#660708] text-white text-sm font-bold px-6 py-3 rounded-lg transition-colors cursor-pointer shadow-[0_1px_2px_rgba(0,0,0,0.08)] w-full sm:w-auto text-center whitespace-nowrap"
                >
                  Start free trial
                </button>
              </form>
            )}

          </div>
        </div>

        {/* Animated KOT / Bill Receipt Printer */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center w-full min-h-[460px]">
          {/* Printer Feed Machine Head */}
          <div className="w-full max-w-[340px] z-20">
            <div className="w-[85%] mx-auto h-4 bg-[#161a1d] rounded-t-lg border-x-4 border-t-4 border-neutral-700 relative shadow-inner">
              {/* Paper slot exit */}
              <div className="absolute inset-x-3 bottom-0 h-1 bg-[#0b090a] rounded-t"></div>
            </div>
          </div>

          {/* Receipts Paper Scroll */}
          <div className="w-full max-w-[340px] overflow-hidden mt-[-1px] pb-6 relative z-10">
            <div
              key={printKey}
              className="receipts-animate flex flex-col items-center"
            >
              {/* Ticket 1: KOT Bill Receipt */}
              <div className="w-[85%] bg-white border border-[#d3d3d3] p-5 shadow-[0_8px_20px_rgba(0,0,0,0.06)] font-mono text-xs text-[#161a1d] relative rounded-b-xl">

                {/* Brand Header */}
                <div className="flex justify-between items-center mb-3">
                  <img src={logoRed} alt="DineDash Logo" className="h-5 w-auto object-contain" />
                  <span className="text-[10px] font-bold text-[#ba181b] bg-[#ba181b]/10 px-2 py-0.5 rounded">LIVE ORDER</span>
                </div>

                {/* Header info */}
                <div className="flex justify-between items-center border-b border-dashed border-[#d3d3d3] pb-3 mb-3">
                  <div>
                    <p className="font-bold text-xs text-[#0b090a]">KOT #912</p>
                    <p className="text-[#b1a7a6] font-bold mt-0.5">TABLE 4</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[#b1a7a6] font-bold">FLOOR 2</p>
                    <p className="text-[#b1a7a6]/70 font-bold mt-0.5">3 GUESTS · 9:15 PM</p>
                  </div>
                </div>

                {/* Items */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <div>
                      <span className="font-bold text-[#0b090a]">1x</span> Paneer Butter Masala
                    </div>
                    <span className="font-semibold text-neutral-600">₹320</span>
                  </div>
                  <div className="flex justify-between">
                    <div>
                      <span className="font-bold text-[#0b090a]">2x</span> Garlic Naan
                    </div>
                    <span className="font-semibold text-neutral-600">₹90</span>
                  </div>
                  <div className="flex justify-between">
                    <div>
                      <span className="font-bold text-[#0b090a]">1x</span> Tandoori Roti
                    </div>
                    <span className="font-semibold text-neutral-600">₹30</span>
                  </div>
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-bold text-[#0b090a]">1x</span> Mango Lassi
                    </div>
                    <span className="font-semibold text-neutral-600">₹120</span>
                  </div>
                </div>

                {/* Footer Summary */}
                <div className="border-t border-dashed border-[#d3d3d3] pt-3 flex justify-between items-center">
                  <span className="font-bold text-[#0b090a] text-xs">Total Amount</span>
                  <span className="font-bold text-[#ba181b] text-sm">₹560</span>
                </div>

                <div className="mt-4 text-center">
                  <span className="inline-flex items-center gap-1.5 bg-[#ba181b]/10 text-[#ba181b] px-2 py-0.5 rounded-full text-[9px] font-bold font-sans">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ba181b] animate-pulse"></span>
                    Sent to KDS Monitor
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Trigger Button */}
          <div className="mt-2 flex justify-center">
            <button
              onClick={() => { playPrinterSound(); setPrintKey(prev => prev + 1) }}
              className="inline-flex items-center gap-2 border border-[#d3d3d3] hover:border-[#ba181b] hover:bg-[#ba181b]/5 hover:text-[#ba181b] text-[#161a1d]/70 text-[11px] font-bold py-1.5 px-3.5 rounded-lg transition-all cursor-pointer shadow-sm active:scale-95 bg-white"
            >
              Reprint Bill Demo
            </button>
          </div>
        </div>
      </section>

      {/* 3. HIGHLIGHT SLIDER */}
      <section className="w-full bg-[#161a1d] py-4 border-y border-[#d3d3d3]/20 overflow-hidden relative">
        <div className="flex whitespace-nowrap animate-[marquee_25s_linear_infinite] gap-12 font-outfit text-xs font-bold uppercase tracking-widest text-[#f5f3f4]">
          <span>TAP-TO-ORDER</span>
          <span className="text-[#e5383b]">●</span>
          <span>DASHBOARD OVERVIEW</span>
          <span className="text-[#e5383b]">●</span>
          <span>SMART KITCHEN DISPLAYS</span>
          <span className="text-[#e5383b]">●</span>
          <span>COUPON VALIDATION</span>
          <span className="text-[#e5383b]">●</span>
          <span>KOT LIVE STREAMING</span>
          <span className="text-[#e5383b]">●</span>
          <span>ZERO WAIT TIME</span>
          <span className="text-[#e5383b]">●</span>
          <span>WAITER CALL SUMMON</span>
          <span className="text-[#e5383b]">●</span>
          <span>TABLE QR CODES</span>
          <span className="text-[#e5383b]">●</span>
          {/* Duplicate for infinite loop spacing */}
          <span>TAP-TO-ORDER</span>
          <span className="text-[#e5383b]">●</span>
          <span>DASHBOARD OVERVIEW</span>
          <span className="text-[#e5383b]">●</span>
          <span>SMART KITCHEN DISPLAYS</span>
          <span className="text-[#e5383b]">●</span>
          <span>COUPON VALIDATION</span>
          <span className="text-[#e5383b]">●</span>
          <span>KOT LIVE STREAMING</span>
          <span className="text-[#e5383b]">●</span>
          <span>ZERO WAIT TIME</span>
          <span className="text-[#e5383b]">●</span>
          <span>WAITER CALL SUMMON</span>
          <span className="text-[#e5383b]">●</span>
          <span>TABLE QR CODES</span>
        </div>
        <style dangerouslySetInnerHTML={{
          __html: `
          @keyframes marquee {
            0% { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
          }
        `}} />
      </section>

      {/* 4. "SETUP JOURNEY" SECTION (Re-structured to a 3-step setup) */}
      <section id="how" className="px-6 lg:px-16 py-20 max-w-7xl mx-auto w-full">
        <span className="block text-center text-[10px] font-bold tracking-wider text-[#b1a7a6] uppercase mb-3">
          Onboarding Journey
        </span>
        <h2 className="font-outfit text-3xl lg:text-4xl font-bold text-center text-[#0b090a] tracking-tight mb-12">
          Up and running in three simple phases
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="bg-white rounded-xl border border-[#d3d3d3] p-8 shadow-[0_2px_8px_rgba(0,0,0,0.005)]">
            <div className="w-10 h-10 rounded-lg bg-[#f5f3f4] border border-[#d3d3d3] flex items-center justify-center font-bold text-[#ba181b] text-base mb-6">
              1
            </div>
            <h3 className="font-outfit text-lg font-bold text-[#0b090a] mb-3">
              Onboard Your Venue
            </h3>
            <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
              Register, configure your logo, and add menu categories, food items, notes, and images. Add staff members and configure access permissions.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white rounded-xl border border-[#d3d3d3] p-8 shadow-[0_2px_8px_rgba(0,0,0,0.005)]">
            <div className="w-10 h-10 rounded-lg bg-[#f5f3f4] border border-[#d3d3d3] flex items-center justify-center font-bold text-[#ba181b] text-base mb-6">
              2
            </div>
            <h3 className="font-outfit text-lg font-bold text-[#0b090a] mb-3">
              Generate Table QRs
            </h3>
            <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
              Instantly generate unique QR codes for your tables. Print and place them at your tables so customers can access the system.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white rounded-xl border border-[#d3d3d3] p-8 shadow-[0_2px_8px_rgba(0,0,0,0.005)]">
            <div className="w-10 h-10 rounded-lg bg-[#f5f3f4] border border-[#d3d3d3] flex items-center justify-center font-bold text-[#ba181b] text-base mb-6">
              3
            </div>
            <h3 className="font-outfit text-lg font-bold text-[#0b090a] mb-3">
              Instant Guest Access
            </h3>
            <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
              Customers scan, view, and place orders. The kitchen sees order tickets stream on their KDS in real time. Fast, secure, and touchless.
            </p>
          </div>
        </div>
      </section>

      {/* 5. "FEATURE ECOSYSTEM" SECTION (Updated copy and layout) */}
      <section id="features" className="bg-[#161a1d] text-[#f5f3f4] py-20 px-6 lg:px-16 border-y border-[#d3d3d3]/10">
        <div className="max-w-7xl mx-auto w-full">
          <span className="block text-center text-[10px] font-bold tracking-wider text-[#e5383b] uppercase mb-3">
            Feature Ecosystem
          </span>
          <h2 className="font-outfit text-3xl lg:text-4xl font-bold text-center text-white tracking-tight mb-16">
            A unified operations panel for your restaurant floor
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-12 gap-x-8 mb-16">
            {/* Feature 1 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Visual Menu
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Interactive Menu Builder
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Build high-conversion visual menus with categories, tags (veg/non-veg, spicy), and toggle items out of stock instantly.
              </p>
            </div>

            {/* Feature 2 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Display
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Live Kitchen Screen (KDS)
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Forget printed receipts. Orders flow to a digital kitchen board. Chefs track preparation times and mark items ready.
              </p>
            </div>

            {/* Feature 3 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Marketing
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Dynamic Coupon Engine
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Configure promotional coupons (percentage or flat discounts, or free item rewards) and validate them in real time directly inside the customer cart.
              </p>
            </div>

            {/* Feature 4 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Control
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Floor & Table Manager
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Track occupied tables, active billing requests, pending checkouts, and food prep statuses from one dashboard.
              </p>
            </div>

            {/* Feature 5 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Summon Server
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Waiter Calling & Alerts
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Allow guests to summon a server with a single click. Dashboard receives live waiter summoning alerts mapping to exact table numbers.
              </p>
            </div>

            {/* Feature 6 */}
            <div>
              <span className="block text-[10px] font-bold text-[#e5383b] tracking-widest uppercase mb-1">
                Security
              </span>
              <h3 className="font-outfit text-lg font-bold text-white mb-2">
                Smart Staff Roles
              </h3>
              <p className="text-[#b1a7a6] text-sm leading-relaxed font-semibold">
                Control permissions for servers, managers, and kitchen teams to secure business financials and operations.
              </p>
            </div>
          </div>

          {/* Checklist */}
          <div className="border-t border-[#d3d3d3]/15 pt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              'Zero guest downloads required',
              'Runs natively in mobile browsers',
              'Dynamic coupon validation',
              'Real-time order status tracker',
              'PDF bill generation & printing',
              'Universal responsive dashboard layout'
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-sm font-bold">
                <svg className="w-5 h-5 text-[#e5383b] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. PRICING SECTION (Upgraded to premium card grid design instead of tabular list) */}
      <section id="pricing" className="px-6 lg:px-16 py-20 max-w-7xl mx-auto w-full">
        <span className="block text-center text-[10px] font-bold tracking-wider text-[#b1a7a6] uppercase mb-3">
          Pricing Plans
        </span>
        <h2 className="font-outfit text-3xl lg:text-4xl font-bold text-center text-[#0b090a] tracking-tight mb-2">
          Transparent, order-independent pricing
        </h2>
        <p className="text-[#b1a7a6] text-sm font-semibold text-center mb-14 max-w-lg mx-auto">
          No commission cuts, no hidden service charges. Pick the plan that fits your venue scale.
        </p>

        {/* Side-by-side SaaS Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch justify-center">
          {apiPlans.length > 0 ? (
            apiPlans.map((plan) => {
              const features = getPlanFeatures(plan.id)
              const isHighlighted = plan.id === 'YEARLY'
              return (
                <div
                  key={plan.id}
                  className={`bg-white rounded-xl border flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.005)] p-8 ${isHighlighted ? 'border-2 border-[#ba181b] shadow-[0_8px_30px_rgba(186,24,27,0.03)] relative' : 'border-[#d3d3d3]'
                    }`}
                >
                  {isHighlighted && (
                    <div className="absolute top-0 right-8 -translate-y-1/2 bg-[#ba181b] text-white text-[9px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      Most Picked
                    </div>
                  )}
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-outfit text-lg font-bold text-[#0b090a]">{plan.name}</h3>
                      {plan.id === 'YEARLY' && <span className="text-[#ba181b] text-xs font-bold">2 Months Free</span>}
                    </div>
                    <p className="text-[#b1a7a6] text-xs font-semibold mb-6">{plan.description}</p>
                    <div className="mb-6">
                      <span className="font-outfit text-3xl font-bold text-[#0b090a]">₹{plan.price}</span>
                      <span className="text-xs text-[#b1a7a6] font-semibold"> / {plan.durationDays} days</span>
                    </div>
                    <ul className="space-y-3 text-xs text-[#161a1d] font-semibold mb-8">
                      {features.map((feat, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <span className="text-[#ba181b]">•</span> {feat}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <button
                    onClick={() => navigate('/register')}
                    className={`w-full text-xs font-bold py-3 rounded-lg transition-colors cursor-pointer ${isHighlighted
                        ? 'bg-[#ba181b] hover:bg-[#a4161a] text-white shadow-[0_2px_4px_rgba(0,0,0,0.05)]'
                        : 'border border-[#d3d3d3] hover:bg-[#f5f3f4] text-[#161a1d]'
                      }`}
                  >
                    {isHighlighted ? 'Choose yearly' : 'Choose plan'}
                  </button>
                </div>
              )
            })
          ) : (
            <>
              {/* Card 1: Starter */}
              <div className="bg-white rounded-xl border border-[#d3d3d3] p-8 flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.005)]">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-outfit text-lg font-bold text-[#0b090a]">Starter Plan</h3>
                    <span className="bg-[#f5f3f4] text-[#b1a7a6] text-[10px] font-bold px-2 py-0.5 rounded">7-day free trial</span>
                  </div>
                  <p className="text-[#b1a7a6] text-xs font-semibold mb-6">Perfect for small cafes and food trucks.</p>
                  <div className="mb-6">
                    <span className="font-outfit text-3xl font-bold text-[#0b090a]">₹599</span>
                    <span className="text-xs text-[#b1a7a6] font-semibold"> / month</span>
                  </div>
                  <ul className="space-y-3 text-xs text-[#161a1d] font-semibold mb-8">
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Up to 15 tables
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Live KDS display
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> UPI payments setup
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#b1a7a6]/55">•</span> Email support
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => navigate('/register')}
                  className="w-full border border-[#d3d3d3] hover:bg-[#f5f3f4] text-[#161a1d] text-xs font-bold py-3 rounded-lg transition-colors cursor-pointer"
                >
                  Start free trial
                </button>
              </div>

              {/* Card 2: Growth (Highlighted) */}
              <div className="bg-white rounded-xl border-2 border-[#ba181b] p-8 flex flex-col justify-between shadow-[0_8px_30px_rgba(186,24,27,0.03)] relative">
                <div className="absolute top-0 right-8 -translate-y-1/2 bg-[#ba181b] text-white text-[9px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Most Picked
                </div>
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-outfit text-lg font-bold text-[#0b090a]">Growth Plan</h3>
                    <span className="text-[#ba181b] text-xs font-bold">Save ₹198</span>
                  </div>
                  <p className="text-[#b1a7a6] text-xs font-semibold mb-6">Best for busy bistros and family diners.</p>
                  <div className="mb-6">
                    <span className="font-outfit text-3xl font-bold text-[#0b090a]">₹1,599</span>
                    <span className="text-xs text-[#b1a7a6] font-semibold"> / 3 months</span>
                  </div>
                  <ul className="space-y-3 text-xs text-[#161a1d] font-semibold mb-8">
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Up to 50 tables
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Multi-floor operations
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Full billing & reporting panel
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Priority Whatsapp support
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => navigate('/register')}
                  className="w-full bg-[#ba181b] hover:bg-[#a4161a] text-white text-xs font-bold py-3 rounded-lg transition-colors cursor-pointer shadow-[0_2px_4px_rgba(0,0,0,0.05)]"
                >
                  Choose growth
                </button>
              </div>

              {/* Card 3: Professional */}
              <div className="bg-white rounded-xl border border-[#d3d3d3] p-8 flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.005)]">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-outfit text-lg font-bold text-[#0b090a]">Professional</h3>
                    <span className="text-[#ba181b] text-xs font-bold">Save ₹1,189</span>
                  </div>
                  <p className="text-[#b1a7a6] text-xs font-semibold mb-6">Built for large-scale premium dining halls.</p>
                  <div className="mb-6">
                    <span className="font-outfit text-3xl font-bold text-[#0b090a]">₹5,999</span>
                    <span className="text-xs text-[#b1a7a6] font-semibold"> / 12 months</span>
                  </div>
                  <ul className="space-y-3 text-xs text-[#161a1d] font-semibold mb-8">
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Unlimited tables & floors
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Analytics dashboard logs
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> Dedicated customer manager
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-[#ba181b]">•</span> API integrations access
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => navigate('/register')}
                  className="w-full border border-[#d3d3d3] hover:bg-[#f5f3f4] text-[#161a1d] text-xs font-bold py-3 rounded-lg transition-colors cursor-pointer"
                >
                  Start free trial
                </button>
              </div>
            </>
          )}
        </div>

        <p className="text-center text-[#b1a7a6] text-xs font-bold mt-10">
          * GST excluded. Standard UPI, card, and net banking gateways apply.
        </p>
      </section>

      {/* 7. PRE-FOOTER CALL TO ACTION */}
      <section className="bg-[#660708] text-white py-16 px-6 lg:px-16 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-outfit text-3xl lg:text-4xl font-bold tracking-tight mb-8">
            Tonight's orders could already be streaming to your kitchen.
          </h2>
          <button
            onClick={() => navigate('/register')}
            className="bg-white hover:bg-[#f5f3f4] active:bg-[#d3d3d3] text-[#660708] text-sm font-bold px-8 py-3.5 rounded-lg transition-colors cursor-pointer shadow-[0_1px_2px_rgba(0,0,0,0.15)] mb-4"
          >
            Launch Your DineDash Menu
          </button>
          <p className="text-red-100/70 text-xs font-bold">
            Start free week • No payment details requested • 10-minute setup
          </p>
        </div>
      </section>

      {/* 8. CONTACT & FOOTER SECTION */}
      <section id="contact" className="bg-[#f5f3f4] px-6 lg:px-16 py-20 border-t border-[#d3d3d3]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column info */}
          <div className="lg:col-span-5 text-left">
            <span className="block text-[10px] font-bold tracking-wider text-[#b1a7a6] uppercase mb-3">
              Get In Touch
            </span>
            <h2 className="font-outfit text-3xl lg:text-4xl font-bold text-[#0b090a] tracking-tight mb-10">
              Need a custom integration?
            </h2>

            <div className="space-y-8 font-medium">
              <div>
                <p className="text-[10px] font-bold text-[#b1a7a6] uppercase tracking-widest mb-1.5">Email Support</p>
                <a href="mailto:compuniclimited@gmail.com" className="text-[#161a1d] text-sm font-bold hover:underline">
                  compuniclimited@gmail.com
                </a>
                <p className="text-[#b1a7a6] text-xs mt-1">General inquiries, custom API hooks, or billing logs.</p>
              </div>

              <div>
                <p className="text-[10px] font-bold text-[#b1a7a6] uppercase tracking-widest mb-1.5">Support Hours</p>
                <p className="text-[#161a1d] text-sm font-bold">9:00 AM – 7:00 PM IST, Monday to Saturday</p>
                <p className="text-[#b1a7a6] text-xs mt-1">Our average response turn-around is under three hours.</p>
              </div>
            </div>
          </div>

          {/* Right Column Form */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-[#d3d3d3] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.005)]">
            {contactSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-12 h-12 rounded-full bg-red-50 text-[#ba181b] flex items-center justify-center mb-4 border border-red-100">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="font-outfit text-lg font-bold text-[#0b090a] mb-1">Message Sent!</h3>
                <p className="text-[#b1a7a6] text-sm">We'll get back to you as soon as possible.</p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-[#b1a7a6] uppercase tracking-wider mb-2">Your Name</label>
                    <input
                      type="text"
                      required
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder="Rajesh Kumar"
                      className="w-full px-4 py-2.5 rounded-lg border border-[#d3d3d3] bg-white text-[#161a1d] placeholder-[#b1a7a6] text-sm focus:outline-none focus:border-[#ba181b] focus:ring-1 focus:ring-[#ba181b] transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#b1a7a6] uppercase tracking-wider mb-2">Email Address</label>
                    <input
                      type="email"
                      required
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder="you@email.com"
                      className="w-full px-4 py-2.5 rounded-lg border border-[#d3d3d3] bg-white text-[#161a1d] placeholder-[#b1a7a6] text-sm focus:outline-none focus:border-[#ba181b] focus:ring-1 focus:ring-[#ba181b] transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#b1a7a6] uppercase tracking-wider mb-2">Subject</label>
                  <select
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-lg border border-[#d3d3d3] bg-white text-[#161a1d] text-sm focus:outline-none focus:border-[#ba181b] focus:ring-1 focus:ring-[#ba181b] transition-all"
                  >
                    <option>General Query</option>
                    <option>Pricing & Subscription</option>
                    <option>Technical Support</option>
                    <option>Custom Request</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#b1a7a6] uppercase tracking-wider mb-2">Message</label>
                  <textarea
                    rows={4}
                    required
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    placeholder="Tell us how we can help..."
                    className="w-full px-4 py-2.5 rounded-lg border border-[#d3d3d3] bg-white text-[#161a1d] placeholder-[#b1a7a6] text-sm focus:outline-none focus:border-[#ba181b] focus:ring-1 focus:ring-[#ba181b] transition-all resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#ba181b] hover:bg-[#a4161a] text-white text-sm font-bold py-3 px-4 rounded-lg transition-colors cursor-pointer shadow-[0_1px_2px_rgba(0,0,0,0.08)]"
                >
                  Send message
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#0b090a] text-[#b1a7a6] px-6 lg:px-16 py-12 border-t border-red-950/20 text-center">
        <div className="max-w-7xl mx-auto flex flex-col items-center gap-6">
          <img
            src={logoRed}
            alt="DineDash Logo"
            className="h-11 w-auto object-contain cursor-pointer"
            onClick={() => {
              window.scrollTo({ top: 0, behavior: 'smooth' })
            }}
          />

          <div className="flex flex-wrap justify-center items-center gap-x-6 gap-y-3 text-xs font-bold px-4">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <a href="#contact" className="hover:text-white transition-colors">Contact</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>

          <div className="text-[11px] font-semibold space-y-1 mt-4 text-[#b1a7a6]/70">
            <p>QR-based restaurant ordering · compuniclimited@gmail.com</p>
            <p>© 2026 Compunic Pvt. Limited. All Rights Reserved.</p>
            <p className="text-[10px] text-[#b1a7a6]/50 mt-2 font-medium">
              Created with ❤️ in Indore by{' '}
              <a
                href="https://compunic.co.in"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-white transition-colors"
              >
                Compunic
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
